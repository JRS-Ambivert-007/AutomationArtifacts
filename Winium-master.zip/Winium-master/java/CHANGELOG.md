# Change Log

<!--## Unreleased-->

## v0.1.0-1

- WebDriver Java bindings for Winium
- Exposes the service provided by the native WiniumDriver executable
