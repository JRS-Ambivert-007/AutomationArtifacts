﻿# Change Log

<!--## Unreleased-->
## v0.1.1

- Add constructor using specifed remote address


## v0.1.0

- WebDriver .Net bindings for Winium
- Exposes the service provided by the native WiniumDriver executable





